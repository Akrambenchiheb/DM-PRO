# -*- coding: utf-8 -*-
"""
Classification des Panneaux de Signalisation (GTSRB) avec un CNN Avancé

Ce script met en œuvre un pipeline complet de Data Mining pour la classification
d'images de panneaux de signalisation du dataset GTSRB. L'approche est basée sur
un Réseau de Neurones Convolutif (CNN) profond, en s'inspirant des architectures
modernes de vision par ordinateur.

L'objectif est d'atteindre une performance de pointe (>99% de précision) en
mettant l'accent sur les aspects suivants, conformément aux exigences d'un
projet de niveau Master :

1.  **Prétraitement Robuste :** Normalisation des images pour préparer les
    données pour le réseau.
2.  **Architecture CNN Profonde :** Utilisation de plusieurs couches convolutives,
    de Batch Normalization pour stabiliser l'apprentissage, et de Dropout pour
    la régularisation.
3.  **Data Augmentation :** Augmentation des données d'entraînement pour améliorer
    la capacité du modèle à généraliser sur des images non vues (variations
    de rotation, zoom, etc.).
4.  **Évaluation Rigoureuse :** Analyse des performances via l'accuracy, le
    rapport de classification détaillé (précision, rappel, F1-score) et la
    matrice de confusion.
5.  **Visualisation :** Création de graphiques pour les courbes d'apprentissage
    et la matrice de confusion afin d'interpréter les résultats.
"""

import deeplake
import numpy as np
import cv2
from tqdm import tqdm
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten, Dense, BatchNormalization
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

def load_gtsrb_data():
    """
    Charge les ensembles de données GTSRB (entraînement et test) depuis le hub
    de données Activeloop Deep Lake.

    Returns:
        tuple: Un tuple contenant les datasets d'entraînement et de test.
    """
    print("Chargement des données GTSRB depuis Activloop Hub...")
    ds_train = deeplake.load("hub://activeloop/gtsrb-train")
    ds_test = deeplake.load("hub://activeloop/gtsrb-test")
    print("Données chargées avec succès.")
    return ds_train, ds_test

def prepare_data_for_cnn(ds, num_classes):
    """
    Prétraite les données du dataset pour l'entraînement du CNN.

    Cette fonction effectue les étapes suivantes :
    1. Redimensionne chaque image à une taille fixe de 32x32 pixels. C'est un
       compromis standard entre la préservation des détails et la complexité
       computationnelle pour les architectures CNN sur ce type de dataset.
    2. Convertit les labels en format one-hot encoding.
    3. Normalise les valeurs des pixels de [0, 255] à [0, 1].

    Args:
        ds (deeplake.Dataset): Le dataset à prétraiter.
        num_classes (int): Le nombre total de classes pour l'encodage one-hot.

    Returns:
        tuple: Un tuple (X, y) où X est le tableau des images et y les labels.
    """
    images_list = []
    labels_list = []
    
    # Itérer sur le dataset pour extraire et prétraiter chaque image/label
    for i in tqdm(range(len(ds)), desc="Préparation des données pour le CNN"):
        image = ds.images[i].numpy()
        label = ds.labels[i].numpy(aslist=True)[0]
        
        # Redimensionnement à 32x32
        resized_image = cv2.resize(image, (32, 32))
        images_list.append(resized_image)
        labels_list.append(label)
    
    # Conversion en tableau NumPy et normalisation
    X = np.array(images_list).astype('float32') / 255.0
    # Encodage one-hot des labels
    y = to_categorical(np.array(labels_list), num_classes=num_classes)
    
    return X, y

def build_advanced_cnn_model(num_classes):
    """
    Construit l'architecture du modèle CNN avancé.

    Le modèle est composé de blocs convolutifs suivis de couches de
    classification. Chaque bloc contient :
    - Conv2D : Pour l'extraction des caractéristiques locales.
    - BatchNormalization : Pour stabiliser et accélérer l'apprentissage.
    - MaxPooling2D : Pour réduire la dimensionnalité spatiale.
    - Dropout : Pour la régularisation afin d'éviter le surapprentissage.

    Args:
        num_classes (int): Le nombre de neurones de la couche de sortie.

    Returns:
        tensorflow.keras.Model: Le modèle CNN compilé.
    """
    model = Sequential([
        # Premier bloc convolutif
        Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 3)),
        BatchNormalization(),
        Conv2D(32, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.2),

        # Deuxième bloc convolutif
        Conv2D(64, (3, 3), activation='relu'),
        BatchNormalization(),
        Conv2D(64, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.3),

        # Couches de classification
        Flatten(),
        Dense(128, activation='relu'),
        BatchNormalization(),
        Dropout(0.5),
        Dense(num_classes, activation='softmax') # Softmax pour la classification multi-classe
    ])
    
    # Compilation du modèle avec l'optimiseur Adam et la perte cross-entropy
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

def plot_history(history):
    """
    Visualise et sauvegarde les courbes d'apprentissage (accuracy et perte)
    du modèle au cours des époques.

    Args:
        history (History): L'objet retourné par la méthode `fit` de Keras.
    """
    plt.figure(figsize=(12, 5))
    
    # Graphique de l'accuracy
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'], label='Accuracy (entraînement)')
    plt.plot(history.history['val_accuracy'], label='Accuracy (validation)')
    plt.title('Courbe d\'Accuracy du Modèle')
    plt.xlabel('Époque'); plt.ylabel('Accuracy'); plt.legend()
    
    # Graphique de la perte
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'], label='Perte (entraînement)')
    plt.plot(history.history['val_loss'], label='Perte (validation)')
    plt.title('Courbe de Perte du Modèle')
    plt.xlabel('Époque'); plt.ylabel('Perte'); plt.legend()
    
    plt.savefig('cnn_learning_curves.png')
    plt.close()
    print("\nLes courbes d'apprentissage ont été sauvegardées dans 'cnn_learning_curves.png'.")

def main():
    """
    Fonction principale pour exécuter l'ensemble du pipeline :
    chargement, prétraitement, entraînement et évaluation.
    """
    ds_train, ds_test = load_gtsrb_data()
    NUM_CLASSES = 43
    
    X_train_full, y_train_full = prepare_data_for_cnn(ds_train, NUM_CLASSES)
    X_test, y_test = prepare_data_for_cnn(ds_test, NUM_CLASSES)

    # Scinder les données d'entraînement en un ensemble d'entraînement et de validation
    # pour surveiller le surapprentissage.
    X_train, X_val, y_train, y_val = train_test_split(
        X_train_full, y_train_full, test_size=0.2, random_state=42, stratify=y_train_full
    )

    model = build_advanced_cnn_model(NUM_CLASSES)
    model.summary()

    # Configuration de la Data Augmentation
    # Génère de nouvelles images en appliquant des transformations aléatoires
    # pour rendre le modèle plus robuste.
    datagen = ImageDataGenerator(
        rotation_range=10,      # Rotation aléatoire de ±10 degrés
        zoom_range=0.1,         # Zoom aléatoire de ±10%
        width_shift_range=0.1,  # Décalage horizontal de ±10%
        height_shift_range=0.1  # Décalage vertical de ±10%
    )
    datagen.fit(X_train)

    print("\n--- Lancement de l'entraînement du modèle CNN avancé ---")
    history = model.fit(
        datagen.flow(X_train, y_train, batch_size=64),
        epochs=30,
        validation_data=(X_val, y_val),
        verbose=1
    )
    print("--- Entraînement terminé ---")

    print("\n--- Évaluation finale du modèle sur l'ensemble de test ---")
    loss, accuracy = model.evaluate(X_test, y_test)
    print(f"Accuracy sur l'ensemble de test : {accuracy * 100:.2f}%")
    print(f"Perte sur l'ensemble de test : {loss:.4f}")

    # Prédictions et rapport de classification détaillé
    y_pred_probs = model.predict(X_test)
    y_pred = np.argmax(y_pred_probs, axis=1)
    y_true = np.argmax(y_test, axis=1)
    
    print("\nRapport de Classification :")
    print(classification_report(y_true, y_pred))

    # Génération et sauvegarde de la matrice de confusion
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(15, 12))
    sns.heatmap(cm, annot=False, fmt='d', cmap='viridis') # annot=False pour la lisibilité
    plt.title('Matrice de Confusion - Modèle CNN Avancé')
    plt.ylabel('Vraie classe'); plt.xlabel('Classe prédite')
    plt.savefig('confusion_matrix_cnn_advanced.png')
    plt.close()
    print("La matrice de confusion a été sauvegardée dans 'confusion_matrix_cnn_advanced.png'.")
    
    # Génération et sauvegarde des courbes d'apprentissage
    plot_history(history)

if __name__ == "__main__":
    main()
